Requirement:

Requries readline to be installed:
run the command:
sudo apt-get install libreadline6 libreadline6-dev

basic code of a shell.
commands like ls,cd,echo,pwd work

every other command is considered as a system command.
